
# Part 1
def students_gpas(students: list, gpas: list) ->dict:
    pass

def runners_places(runners: list) -> dict:
    pass

def min_value(l: list, f) -> int:
    pass


# Part 2
def stocks(db: {str: [(str, int, int)]}) -> {str}:
    pass

def clients_by_volume(db: {str: [(str, int, int)]}) -> [str]:
    pass


def stocks_by_volume(db: {str: [(str, int, int)]}) -> [(str, int)]:
    pass



def by_stock(db: {str: [(str, int, int)]}) -> {str: {str: [(int, int)]}}:
    pass


def summary(db: {str: [(str, int, int)]}, prices: {str: int}) -> {str: ({str: int}, int)}:
    pass


if __name__ == '__main__':

    # Note: the keys in this dicts are not specified in alphabetical order
    db1 = {
        'Carl': [('Intel', 30, 40), ('Dell', 20, 50), ('Intel', -10, 60), ('Apple', 20, 55)],
        'Barb': [('Intel', 20, 40), ('Intel', -10, 45), ('IBM', 40, 30), ('Intel', -10, 35)],
        'Alan': [('Intel', 20, 10), ('Dell', 10, 50), ('Apple', 80, 80), ('Dell', -10, 55)],
        'Dawn': [('Apple', 40, 80), ('Apple', 40, 85), ('Apple', -40, 90)]
    }

    db2 = {
        'Hope': [('Intel', 30, 40), ('Dell', 20, 50), ('IBM', 10, 80), ('Apple', 20, 90), ('QlCom', 20, 20)],
        'Carl': [('QlCom', 30, 22), ('QlCom', 20, 23), ('QlCom', -20, 25), ('QlCom', -30, 28)],
        'Barb': [('Intel', 80, 42), ('Intel', -80, 45), ('Intel', 90, 28)],
        'Fran': [('BrCom', 210, 62), ('BrCom', -20, 64), ('BrCom', -10, 66), ('BrCom', 10, 55)],
        'Alan': [('Intel', 20, 10), ('Dell', 10, 50), ('Apple', 80, 80), ('Dell', -10, 55)],
        'Gabe': [('IBM', 40, 82), ('QlCom', 80, 25), ('IBM', -20, 84), ('BrCom', 50, 65), ('QlCom', -40, 28)],
        'Dawn': [('Apple', 40, 92), ('Apple', 40, 98), ('Apple', -40, 92)],
        'Evan': [('Apple', 50, 92), ('Dell', 20, 50), ('Apple', -10, 95), ('Apple', 20, 95), ('Dell', -20, 90)]
    }

    prices1 = {'IBM': 65, 'Intel': 60, 'Dell': 55, 'Apple': 70}

    prices2 = {'IBM': 85, 'Intel': 45, 'Dell': 50, 'Apple': 90, 'QlCom': 20, 'BrCom': 70}

    print('\nTesting stocks')
    print('stocks(db1):', stocks(db1))
    print('stocks(db2):', stocks(db2))

    print('\nTesting clients_by_volume')
    print('clients_by_volume(db1):', clients_by_volume(db1))
    print('clients_by_volume(db2):', clients_by_volume(db2))

    print('\nTesting stocks_by_volume')
    print('stocks_by_volume(db1):', stocks_by_volume(db1))
    print('stocks_by_volume(db2):', stocks_by_volume(db2))

    print('\nTesting by_stock')
    print('by_stock(db1):', by_stock(db1))
    print('by_stock(db2):', by_stock(db2))

    print('\nTesting summary')
    print('summary(db1):', summary(db1, prices1))
    print('summary(db2):', summary(db2, prices2))

    print('\ndriver testing with batch_self_check:')

    # comment this part out if you want to test it yourself
    import driver

    driver.default_file_name = 'tests1.txt'
    #     driver.default_show_traceback = True
    #     driver.default_show_exception = True
    #     driver.default_show_exception_message = True
    driver.driver()